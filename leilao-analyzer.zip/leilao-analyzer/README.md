# 🏠 Douglas Rosa — Analisador Inteligente de Leilões

App web com IA que analisa links de leilões imobiliários e gera um dashboard completo de viabilidade.

---

## 🚀 Como hospedar no Railway (passo a passo)

### Pré-requisitos
- Conta gratuita no [GitHub](https://github.com)
- Conta gratuita no [Railway](https://railway.app)
- Sua chave da API da Anthropic (encontre em [console.anthropic.com](https://console.anthropic.com))

---

### Passo 1 — Subir o projeto no GitHub

1. Acesse [github.com](https://github.com) e faça login
2. Clique em **"New repository"** (botão verde no canto superior direito)
3. Nome do repositório: `leilao-analyzer`
4. Deixe como **Public** e clique em **"Create repository"**
5. Na próxima tela, clique em **"uploading an existing file"**
6. Arraste **todos os arquivos e pastas** deste projeto para a área de upload
7. Clique em **"Commit changes"**

---

### Passo 2 — Criar o serviço no Railway

1. Acesse [railway.app](https://railway.app) e clique em **"Login"**
2. Faça login com sua conta do **GitHub**
3. Clique em **"New Project"**
4. Selecione **"Deploy from GitHub repo"**
5. Encontre e selecione o repositório `leilao-analyzer`
6. O Railway vai detectar automaticamente que é um projeto Node.js e iniciar o deploy

---

### Passo 3 — Configurar a chave da API

1. No painel do Railway, clique no seu serviço
2. Vá na aba **"Variables"**
3. Clique em **"New Variable"**
4. Adicione:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** sua chave da API (começa com `sk-ant-...`)
5. Clique em **"Add"**
6. O Railway vai reiniciar automaticamente com a variável configurada

---

### Passo 4 — Acessar o app

1. Ainda no Railway, clique na aba **"Settings"**
2. Em **"Domains"**, clique em **"Generate Domain"**
3. Você vai receber um link como: `leilao-analyzer.up.railway.app`
4. Acesse esse link — o app está no ar! 🎉

---

## 💰 Custo

- **Railway:** Free tier inclui $5/mês de crédito — suficiente para uso moderado
- **Anthropic API:** ~$0,003 por análise (Claude Sonnet)

---

## 🔧 Como funciona

1. Você cola a URL do leilão
2. O servidor Node.js acessa a página e extrai o conteúdo
3. O conteúdo é enviado para o Claude (Anthropic API)
4. A IA analisa e retorna o diagnóstico estruturado
5. O dashboard é montado automaticamente

---

## 📁 Estrutura do projeto

```
leilao-analyzer/
├── src/
│   └── server.js        # Backend Node.js (scraping + API)
├── public/
│   └── index.html       # Frontend do dashboard
├── package.json
├── railway.toml
└── README.md
```
