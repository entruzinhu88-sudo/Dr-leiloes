const express = require('express');
const axios = require('axios');
const cheerio = require('cheerio');
const Anthropic = require('@anthropic-ai/sdk');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const SYSTEM_PROMPT = `Você é um especialista sênior em leilões imobiliários da Douglas Rosa Assessoria em Leilões.

Você recebe o conteúdo HTML/texto extraído de uma página de leilão. Analise TODOS os dados disponíveis e gere um diagnóstico completo e estruturado.

Cubra obrigatoriamente:
1. IDENTIFICAÇÃO DO IMÓVEL: tipo, endereço, área, matrícula, comarca
2. DADOS DO LEILÃO: modalidade, processo, leiloeiro, datas, lance mínimo, avaliação, desconto
3. ANÁLISE JURÍDICA: situação dominial, ônus, ocupação, irregularidades, classifique riscos como alto/médio/baixo
4. ANÁLISE DE MERCADO: preço/m², comparativo, potencial, liquidez
5. ANÁLISE FINANCEIRA: lance máximo sugerido, ROI, custos
6. VEREDICTO: APROVADO / ATENÇÃO / REPROVADO com score 0-100

Responda APENAS em JSON válido, sem texto antes ou depois, sem markdown:
{
  "verdict": "aprovado|atencao|reprovado",
  "score": 85,
  "verdictTitle": "Título curto do veredicto",
  "verdictSubtitle": "Frase explicando o veredicto",
  "property": {
    "tipo": "Apartamento",
    "endereco": "Endereço completo",
    "area": "87m²",
    "matricula": "12.345 - 1º CRI",
    "dormitorios": "3",
    "vaga": "1 vaga coberta",
    "estado": "Ocupado pelo devedor"
  },
  "auction": {
    "modalidade": "Judicial — Execução Hipotecária",
    "processo": "0001234-56.2021.8.26.0100",
    "leiloeiro": "Nome do Leiloeiro",
    "data1Leilao": "15/07/2025",
    "data2Leilao": "22/07/2025",
    "avaliacao": "R$ 580.000",
    "lanceMinimo": "R$ 290.000",
    "desconto": "50%"
  },
  "financial": {
    "avaliacao": "R$ 580.000",
    "lanceMaxSugerido": "R$ 320.000",
    "custoTotal": "R$ 358.000",
    "valorMercado": "R$ 540.000",
    "lucroEstimado": "R$ 182.000",
    "roi": "50,8%",
    "precoM2Leilao": "R$ 3.678/m²",
    "precoM2Mercado": "R$ 6.207/m²"
  },
  "metrics": [
    {"icon":"📍","label":"Localização","value":"Bairro","badge":"tipo","badgeColor":"coral"},
    {"icon":"📐","label":"Área","value":"87m²","sub":"3 dormitórios"},
    {"icon":"🏷️","label":"Desconto","value":"50%","badge":"judicial","badgeColor":"green"},
    {"icon":"💰","label":"Lance Mínimo","value":"R$ 290k","sub":"vs avaliação"},
    {"icon":"📈","label":"ROI Estimado","value":"50,8%","badge":"acima da meta","badgeColor":"green"},
    {"icon":"⚡","label":"Score","value":"85/100","badge":"aprovado","badgeColor":"green"}
  ],
  "risks": [
    {"level":"baixo","tag":"Situação Dominial","text":"Descrição do risco"},
    {"level":"medio","tag":"Ocupação","text":"Descrição do risco"},
    {"level":"alto","tag":"Débitos","text":"Descrição do risco"}
  ],
  "analysis": "Análise completa de mercado e parecer técnico em 3-4 parágrafos separados por \\n\\n",
  "documents": [
    {"name":"Edital Completo","type":"pdf","size":"—","status":"identificado"},
    {"name":"Matrícula","type":"pdf","size":"—","status":"identificado"}
  ]
}`;

// Scraping endpoint
app.post('/api/analyze', async (req, res) => {
  const { url } = req.body;
  if (!url) return res.status(400).json({ error: 'URL obrigatória' });

  try {
    // 1. Scrape the page
    let pageContent = '';
    try {
      const response = await axios.get(url, {
        timeout: 15000,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Language': 'pt-BR,pt;q=0.9',
        }
      });

      const $ = cheerio.load(response.data);

      // Remove scripts, styles, nav, footer
      $('script, style, nav, footer, header, iframe, noscript').remove();

      // Extract meaningful content
      const title = $('title').text().trim();
      const h1 = $('h1').map((_, el) => $(el).text().trim()).get().join(' | ');
      const h2 = $('h2').map((_, el) => $(el).text().trim()).get().slice(0, 10).join(' | ');

      // Get main content text
      const bodyText = $('body').text()
        .replace(/\s+/g, ' ')
        .replace(/\n+/g, '\n')
        .trim()
        .slice(0, 8000); // limit to 8000 chars

      pageContent = `URL: ${url}
TÍTULO: ${title}
H1: ${h1}
H2: ${h2}
CONTEÚDO:
${bodyText}`;

    } catch (scrapeError) {
      // If scraping fails, still try to analyze with just the URL
      pageContent = `URL: ${url}
NOTA: Não foi possível acessar o conteúdo da página (possível bloqueio ou timeout).
Por favor, gere uma análise baseada no padrão da URL e no portal identificado.`;
    }

    // 2. Analyze with Claude
    const message = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 2000,
      system: SYSTEM_PROMPT,
      messages: [{
        role: 'user',
        content: `Analise este leilão com base no conteúdo extraído:\n\n${pageContent}`
      }]
    });

    const rawText = message.content.map(b => b.text || '').join('');

    let result;
    try {
      const clean = rawText.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      result = JSON.parse(clean);
    } catch (parseError) {
      return res.status(500).json({ error: 'Erro ao processar resposta da IA', raw: rawText });
    }

    res.json({ success: true, data: result, url });

  } catch (err) {
    console.error('Erro na análise:', err.message);
    res.status(500).json({ error: 'Erro interno: ' + err.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🔥 Douglas Rosa Analisador rodando na porta ${PORT}`));
